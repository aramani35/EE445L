#include <stdint.h>

void Piano_Init(void);
uint32_t Piano_In(void);
